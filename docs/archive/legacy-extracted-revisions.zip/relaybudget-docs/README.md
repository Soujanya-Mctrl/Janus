# RelayBudget — product and engineering dossier

**Payment-aware recovery for multi-agent workflows.**

Prepared 6 November 2026, Asia/Kolkata. Status: proposed design; no application, deployed contracts, customer pilots, audits, or product benchmarks are represented as complete.

## The product in one minute

A company gives an orchestrator a 1,000-USDC treasury. It allocates 100 USDC to task A and separate budgets to tasks B, C, and D. Agent A spends 20 USDC and fails. The other tasks continue. When a suitable worker becomes available, it resumes A's checkpoint with authority over the available 80 USDC. Old authority is fenced off, previous purchases are reused, and unresolved payment commitments remain reserved. The owner can cancel tasks and recover uncommitted funds through an independent client.

Money belongs to a task account; workers receive temporary authority. A replacement does not inherit the owner's key.

## Read in this order

1. [PRD: problem, customer, requirements, acceptance criteria](01-prd.md)
2. [Research, competition, and demand validation](02-research-and-market.md)
3. [Technical architecture, SDK, backend, and deployment](03-technical-architecture.md)
4. [Smart-contract specification and financial state machine](04-contract-specification.md)
5. [Phased implementation with Codex and development tools](05-codex-build-playbook.md)
6. [Testing, security review, and reproducible evaluation](06-evaluation-and-security.md)
7. [Sponsor selection and submission evidence](07-sponsor-plan.md)
8. [Economics, stablecoin accounting, and token policy](08-economics.md)
9. [Whitepaper draft, pitch, and demo script](09-whitepaper-and-pitch.md)
10. [Verified source register and evidence limitations](10-sources.md)

Supporting material:

- [Repository instruction template](templates/AGENTS.template.md)
- [Security review report template](templates/security-review.template.md)
- [Benchmark manifest](templates/benchmark-manifest.template.json)
- [Results table with no fabricated observations](templates/results.template.csv)
- [Environment-variable template](templates/env.example)
- [Build and submission evidence checklist](templates/evidence-checklist.md)

## Decisions that prevent scope drift

| Decision | Position |
|---|---|
| Product | Framework-adaptable TypeScript SDK plus an example dashboard; not a general agent-hosting platform |
| Core contribution | Task-level budget conservation, fenced handoff, and payment reconciliation across worker failure |
| First workflow | A small research procurement workflow with independently verifiable purchased artifacts |
| Money | One supported stablecoin-like token per treasury; no native project token |
| Preferred sponsor route | EF CROPS + Hedera x402 + Arkiv, conditional on the Phase 0 payment compatibility spike |
| Financial source of truth | Immutable, non-upgradeable task treasury contract; backend is a reconstructable projection |
| Privacy | Confidential task payloads offchain; public balances, policies, and payment events in the MVP |
| Independent recovery | Owner can recover available principal without our orchestrator, database, facilitator, or Arkiv; still needs chain access, owner key, and gas |
| Unresolved purchases | Reserved until confirmed settled or contractually expired; never silently reassigned |
| Novelty | An integration and correctness hypothesis, not a claim of inventing retries, wallets, or idempotency |

## Current build status

All product metrics are **not measured**. Quantitative acceptance thresholds in this dossier are proposed engineering targets. Research results remain scoped to the original papers. This package specifies how to generate evidence; it does not contain evidence that the proposed application already works.

The documentation was checked for local link integrity, consistency of the budget example, and template syntax. Those checks are distinct from software tests or a smart-contract audit.

## Immediate next action

Execute Phase 0 in the build playbook: settle one real testnet payment through a budget-enforcing contract adapter, verify how outstanding authorizations expire, and test direct owner withdrawal. If this cannot be demonstrated, simplify or change the payment route before investing in UI.
